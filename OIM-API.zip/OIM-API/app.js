const express=require('express');
const app=express();
const mongoose=require('mongoose');
var bodyparser=require('body-parser')
app.use(express.json())
app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());
//require('./model/usermodel');

const router=express.Router();
mongoose.connect("mongodb://localhost:27017/oim",{useUnifiedTopology:true,useNewUrlParser:true});
var connection=mongoose.connection;
connection.once('open',function(){
    console.log("sucess")
})

router.get('/home',(req,res)=>{
    res.send("hello");
    
})

const user= require('./routes/user')
app.use('/',router)
app.use(user)

app.listen(3000,()=>{
    console.log("server is running at port 3000");
})                  