
const usermodel=require('../model/usermodel');

module.exports.createusertype=(req,res)=>{
    console.log(req.body)
    const usertype=req.body.usertype;
    
    const user= new usermodel({
    usertype:usertype,
    createdOn:new Date()
    });
    user.save()
        
    
}