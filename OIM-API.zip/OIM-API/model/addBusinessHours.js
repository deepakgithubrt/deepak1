const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
    
   
        createdBy:{
            type:String,
            required:false
        },
        createdOn:{
            type:Date,
            required:false
        },
        updatedBy:{
            type:String,
            required:false,
        },
        updatedOn:{
            type:Date,
            required:false
        },
        isDeleted:{
            type:Boolean,
            required:false,
            default: false
        },
        deletedBy:{
            type:String,
            required:false
        },
        deletedOn:{
            type:Date,
            required:false
        },
        usertype:{
            type:String
           
        },
    });
    module.exports=mongoose.model('addBusinessHours',newSchema);