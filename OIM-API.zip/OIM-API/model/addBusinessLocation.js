const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
    
    country:{
        type:String,
        required:false
},
    streetAddress:{
        type:String,
        required:false
},
    city:{
        type:String,
        required:false

    },
    pincode:{
        type:Number,
        required:false

    },
    odisha:{
        type:String,
        required:true

    },
    map:{

    },
        
        createdBy:{
            type:String,
            required:false
        },
        createdOn:{
            type:Date,
            required:false
        },
        updatedBy:{
            type:String,
            required:false,
        },
        updatedOn:{
            type:Date,
            required:false
        },
        isDeleted:{
            type:Boolean,
            required:false,
            default: false
        },
        deletedBy:{
            type:String,
            required:false
        },
        deletedOn:{
            type:Date,
            required:false
        },
        usertype:{
            type:String
           
        },
    });
    module.exports=mongoose.model('addBusinessLocation',newSchema);