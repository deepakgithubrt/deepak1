const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
    name:{
        type:String,
        required:false

    },
    body:{
        type:String,
        required:false

    },
    newMessage:{
        type:String,
        required:false

    },
    messageInput:{
        type:fun,
        required:false
    },
        
    sendMessage:{
        type:fun,
        required:false
    },
    messageTime:{
        type:Number,
        required:false
    },
    chatFilters:{
        type:String,
        required:false

    },
    messageOutput:{
        type:fun,
        required:false
    },



    
         createdBy:{
             type:String,
             require:false
         },
         createdOn:{
             type:Date,
             require:false
         },
         updatedBy:{
             type:String,
             require:false,
         },
         updatedOn:{
             type:Date,
             require:false
         },
         isDeleted:{
             type:Boolean,
             require:false,
             default: false
         },
         deletedBy:{
             type:String,
             require:false
         },
         deletedOn:{
             type:Date,
             require:false
         },


});
module.exports=mongoose.model('message',newSchema);