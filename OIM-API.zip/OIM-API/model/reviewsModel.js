const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
    productName:{
        type:String,
        required:true
    },
    productId:{
        type:String,
        required:false
    },
    rating:{
        type:Number,
        min:1,
        max:5,
        default:5,
        required:true
    },

    
    reviewedBy:{
        type:schema.types.object,
        ref:'user'

    },
    reviewedOn:{
        type:schema.types.object,
        ref:'user'
    },

  
         
         createdBy:{
             type:String,
             require:false
         },
         createdOn:{
             type:Date,
             require:false
         },
         updatedBy:{
             type:String,
             require:false,
         },
         updatedOn:{
             type:Date,
             require:false
         },
         isDeleted:{
             type:Boolean,
             require:false,
             default: false
         },
         deletedBy:{
             type:String,
             require:false
         },
         deletedOn:{
             type:Date,
             require:false
         },


});
module.exports=mongoose.model('review',newSchema);