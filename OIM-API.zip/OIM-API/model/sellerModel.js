const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
  phoneno:{
     type:Number,
     required:false

  },
  otp:{
      type:Number,
      required:true

  },
  password:{
      type:String,
      required:false
    },
  confirmpassword:{
    type:String,
    required:false

  },
  addPhoto:{
    data: Buffer,
    contentType: String

  },
  businessName:{

  },
  businessCategories:{

  },
  ownerName:{
      type:String,
      required:false

  },
 
  
   createdBy:{
             type:String,
             require:false
         },
         createdOn:{
             type:Date,
             require:false
         },
         updatedBy:{
             type:String,
             require:false,
         },
         updatedOn:{
             type:Date,
             require:false
         },
         isDeleted:{
             type:Boolean,
             require:false,
             default: false
         },
         deletedBy:{
             type:String,
             require:false
         },
         deletedOn:{
             type:Date,
             require:false
         },


});
module.exports=mongoose.model('seller',newSchema);