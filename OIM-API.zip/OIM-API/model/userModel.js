const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
    
    username:{
       type: String,
       required:false
    },
    Phoneno:{
        required:true,
        type:Number,
        unique:true,
   },
    
     
    
    password:{
        required:false,

    type:String,
    },
    confirmpassword:{

        required:false,
        type:String,
        
        },
        
            email:{
                type:String,
            required:false

            },
            otp:{
                type:String,
                required:false
               },
        
        createdBy:{
            type:String,
            required:false
        },
        createdOn:{
            type:Date,
            required:false
        },
        updatedBy:{
            type:String,
            required:false,
        },
        updatedOn:{
            type:Date,
            required:false
        },
        isDeleted:{
            type:Boolean,
            required:false,
            default: false
        },
        deletedBy:{
            type:String,
            required:false
        },
        deletedOn:{
            type:Date,
            required:false
        },
        usertype:{
            type:String
           
        },
    });
    module.exports=mongoose.model('user',newSchema);