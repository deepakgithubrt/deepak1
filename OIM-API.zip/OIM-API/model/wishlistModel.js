const mongoose = require('mongoose')

var newSchema=new mongoose.Schema({
    addProduct:{
        type:schema.type.ObjectId,
        required:true,

},
    removeProduct:{
        type:schema.type.ObjectId,
        required:false,

    },
    productId:{
        type:schema.type.ObjectId,
        required:true,

    },
    productCategory:{
        type:Number,
        required:false

    },
    description:{
        type:String,
        required:false

    },
    quantyty:{
        type:String,
        required:false
    },
    totalPrice:{
        type:Number,
        required:false

    },
   createdBy:{
            type:String,
            required:false
        },
        createdOn:{
            type:Date,
            required:false
        },
        updatedBy:{
            type:String,
            required:false,
        },
        updatedOn:{
            type:Date,
            required:false
        },
        isDeleted:{
            type:Boolean,
            required:false,
            default: false
        },
        deletedBy:{
            type:String,
            required:false
        },
        deletedOn:{
            type:Date,
            required:false
        },
        usertype:{
            type:String
           
        },
    });
    module.exports=mongoose.model('wishlist',newSchema);