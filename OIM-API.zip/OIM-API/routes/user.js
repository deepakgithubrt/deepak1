var express=require("express")
const router=express.Router()
const usercontroller=require('../controller/userController')
var bodyparser=require('body-parser');
router.use(express.json())
router.use(bodyparser.urlencoded({extended:true}));
router.use(bodyparser.json());


router.post('/createusertype',usercontroller.createusertype)

module.exports=router