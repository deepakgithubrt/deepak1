for(var num=1;num<=10;num++){
    var value=10;
    console.log(value +" * "+ num+" = "+ value*num);
}
